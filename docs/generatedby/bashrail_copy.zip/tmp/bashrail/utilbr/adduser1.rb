#
# add user
#
# to run this at the prompt..
# http://stackoverflow.com/questions/10313181/pass-ruby-script-file-to-rails-console
#
# usage:    rails r util/adduser1.rb

# u = User.create :name => "Kim Gates",           :email => "kgates",      :role_id => 6,  password: "thisisjustaplaceholder", password_confirmation: "thisisjustaplaceholder" ; u.save!
# u = User.create :name => 'Tara Ross',           :email => 'tross',       :role_id => 5,  password: 'thisisjustaplaceholder', password_confirmation: 'thisisjustaplaceholder' ; u.save!
